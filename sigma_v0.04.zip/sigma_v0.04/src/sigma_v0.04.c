#include<stdio.h>
#include<stdlib.h>
int main(){
int yourself = 0;
int empty = 0;
int c = 0;
    printf("1.work\n");
    printf("2.sleep\n");
    printf("3.chore\n");
    printf("4.chore.\n");
    printf("5.chatting\n");
    printf("6.others\n");
    printf("7.Shut a fuking up I understand because i am me\n");
    scanf("%d",&yourself);
    if(yourself <= 3 ){ 
        printf("Good keep going.\n"); 
        printf("Press Something to terminate...\n"); 
        while ((c = getchar()) == '\n') {
            if (c == EOF) {
            printf("bye!");
            scanf("%d",&empty);
                exit(1);

            }
         }
    }else if(yourself <= 6){
        printf("Be a Sigma, omega, Im not sure. there is surely substitute.\n");
        printf("Dont buy rizz'z anger. And you AIN'T GET THE ONE\n");
    // printf("Dont be a beta, dont be a gamma, dont be a delta, dont be a epsilon, dont be a zeta, dont be a eta, dont be a theta, dont be a iota, dont be a kappa, dont be a lambda, dont be a mu, dont be a nu, dont be a xi, dont be a omicron, dont be a pi, dont be a rho, dont be a sigma, dont be a tau, dont be a upsilon, dont be a phi, dont be a chi, dont be a psi, and of course you shouldnt be an omega.\n");
        printf("Do unity\n");
        printf("It is just reinventing same bad loop again.\n");
        printf("One has falw should be a SIGMA but, you can retreat. do not forget that.\n");
        printf("Press Something to terminate...\n");
        while ((c = getchar()) == '\n') {
            if (c == EOF) {
                 printf("bye!");
                 exit(1);
            }
        }
         
     }else{
        printf("Do unity, organize, read books randaomly from your shelf.\nTalk to someone on VRC randomly\n");
        printf("Say it what you see in your room\n");
        printf("Eat gum\n");
        printf("Press Something to terminate...\n");
        while ((c = getchar()) == '\n') {
          if (c == EOF) {
             printf("bye!");
             scanf("%d",&empty);
             exit(1);
           }
        }
    }
        
return 0;
}
